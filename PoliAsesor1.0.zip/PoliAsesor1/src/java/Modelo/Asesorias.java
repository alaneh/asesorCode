/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Time;

/**
 *
 * @author Administrador
 */


  
    public class Asesorias {
    private String nombre,nombreasesor, descripcion, temas, aula,material,boletaasesor;
    private String hora1inicio,hora2inicio,hora3inicio,hora4inicio,hora5inicio,
                   hora6inicio,hora7inicio;
    private String horafin1,horafin2,horafin3,horafin4,horafin5,horafin6,horafin7;
    private int id,cupomax,cupodis,estado;
    public Asesorias(){
        
    }

    public String getHora1inicio() {
        return hora1inicio;
    }

    public void setHora1inicio(String hora1inicio) {
        this.hora1inicio = hora1inicio;
    }

    public String getHora2inicio() {
        return hora2inicio;
    }

    public void setHora2inicio(String hora2inicio) {
        this.hora2inicio = hora2inicio;
    }

    public String getHora3inicio() {
        return hora3inicio;
    }

    public void setHora3inicio(String hora3inicio) {
        this.hora3inicio = hora3inicio;
    }

    public String getHora4inicio() {
        return hora4inicio;
    }

    public void setHora4inicio(String hora4inicio) {
        this.hora4inicio = hora4inicio;
    }

    public String getHora5inicio() {
        return hora5inicio;
    }

    public void setHora5inicio(String hora5inicio) {
        this.hora5inicio = hora5inicio;
    }

    public String getHora6inicio() {
        return hora6inicio;
    }

    public void setHora6inicio(String hora6inicio) {
        this.hora6inicio = hora6inicio;
    }

    public String getHora7inicio() {
        return hora7inicio;
    }

    public void setHora7inicio(String hora7inicio) {
        this.hora7inicio = hora7inicio;
    }

    public String getHorafin1() {
        return horafin1;
    }

    public void setHorafin1(String horafin1) {
        this.horafin1 = horafin1;
    }

    public String getHorafin2() {
        return horafin2;
    }

    public void setHorafin2(String horafin2) {
        this.horafin2 = horafin2;
    }

    public String getHorafin3() {
        return horafin3;
    }

    public void setHorafin3(String horafin3) {
        this.horafin3 = horafin3;
    }

    public String getHorafin4() {
        return horafin4;
    }

    public void setHorafin4(String horafin4) {
        this.horafin4 = horafin4;
    }

    public String getHorafin5() {
        return horafin5;
    }

    public void setHorafin5(String horafin5) {
        this.horafin5 = horafin5;
    }

    public String getHorafin6() {
        return horafin6;
    }

    public void setHorafin6(String horafin6) {
        this.horafin6 = horafin6;
    }

    public String getHorafin7() {
        return horafin7;
    }

    public void setHorafin7(String horafin7) {
        this.horafin7 = horafin7;
    }

    
    
    public String getNombreasesor() {
        return nombreasesor;
    }

    public void setNombreasesor(String nombreasesor) {
        this.nombreasesor = nombreasesor;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTemas() {
        return temas;
    }

    public void setTemas(String temas) {
        this.temas = temas;
    }

    public String getAula() {
        return aula;
    }

    public void setAula(String aula) {
        this.aula = aula;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getBoletaasesor() {
        return boletaasesor;
    }

    public void setBoletaasesor(String boletaasesor) {
        this.boletaasesor = boletaasesor;
    }

    public int getCupomax() {
        return cupomax;
    }

    public void setCupomax(int cupomax) {
        this.cupomax = cupomax;
    }

    public int getCupodis() {
        return cupodis;
    }

    public void setCupodis(int cupodis) {
        this.cupodis = cupodis;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
    


}
